<script lang="ts">
  /** Transitional owner of query dispatch and local table behavior. */
  import type { ComponentRegistry } from '@victframework/application/renderer';
  import type { UiTableIntent, UiTableState } from '@victframework/ui';
  import RecordsTable from './RecordsTable.svelte';
  import { deriveRowActionInput, resolveRowDetailLink, type ActionResult, type PlanRouteEntry, type PlanSurface } from './logic.js';

  interface Props {
    surface: PlanSurface;
    intent: UiTableIntent;
    initialRows: readonly Record<string, unknown>[];
    dispatch: (actionId: string, input?: unknown) => Promise<ActionResult>;
    registry?: ComponentRegistry;
    /** Renderer action path (local/navigation stay client-side). */
    run?: (actionId: string, input?: unknown) => Promise<ActionResult | void>;
    /** The plan's route table (FT-1 route resolution stays with the host plan). */
    planRoutes?: readonly PlanRouteEntry[];
    /** Host navigation (FT-1): SPA interception for row-detail links. */
    navigate?: (path: string) => void;
  }
  let { surface, intent, initialRows, dispatch, registry, run, planRoutes, navigate }: Props = $props();

  interface QueryPayload {
    filters?: Record<string, string>;
    search?: { text: string; fields: readonly string[] };
    sort?: readonly { field: string; direction: 'asc' | 'desc' }[];
    limit: number;
    offset: number;
  }

  const hasQueryAction = $derived(typeof surface.queryActionId === 'string' && surface.queryActionId.length > 0);
  // The bound view's declared initial sort (@2): the fresh-mount state AND
  // every dispatched query (search, filter, pagination) carry it until the
  // user selects another sort. Seeded from the compiled plan, so dispatched
  // pages can never diverge from the server-loaded page order — the server
  // loads the view WITH its declared sort; without this seed a dispatch that
  // omitted `sort` fell back to the data adapter's own list order, repeating
  // rows across page boundaries and hiding others (QA FINDING-1).
  const declaredSort = $derived(intent.initialSort ?? []);
  const declaredFirst = $derived(declaredSort[0]);
  let search = $state('');
  let filterValues = $state<Record<string, string>>({});
  let sortField = $state<string | null>(null);
  let sortDir = $state<'asc' | 'desc'>('asc');
  let page = $state(0);
  let queryRows = $state<readonly Record<string, unknown>[]>([]);
  let queryTotal = $state<number | null>(null);
  let pending = $state(false);
  // Monotonic query token: only the LATEST issued query may apply its
  // result, so rapid successive searches can never let an earlier response
  // resolve late and overwrite fresher rows (last-issued wins, not
  // last-resolved).
  let queryToken = 0;

  // Route-data changes (path/plan/load refreshes) resync the local state —
  // never stale rows. The token bump also invalidates any query that is
  // still in flight so its late response cannot overwrite the reset.
  $effect(() => {
    void initialRows;
    const declared = declaredFirst;
    queryToken++;
    queryRows = hasQueryAction ? initialRows.slice(0, intent.pageSize) : initialRows;
    queryTotal = initialRows.length;
    page = 0;
    search = '';
    filterValues = {};
    // Mount and route-data changes seed/resync to the view's declared
    // initial sort, not to an unsorted state — the resynced page must stay
    // in declared order.
    sortField = declared?.field ?? null;
    sortDir = declared?.direction ?? 'asc';
  });

  const displayRows = $derived.by(() => {
    if (hasQueryAction) return queryRows;
    let rows = [...initialRows];
    if (search.trim() !== '') {
      const needle = search.trim().toLowerCase();
      rows = rows.filter((row) =>
        intent.search.fields.some((field) => String(row[field] ?? '').toLowerCase().includes(needle)),
      );
    }
    for (const [field, value] of Object.entries(filterValues)) {
      if (value !== '') rows = rows.filter((row) => row[field] === value);
    }
    if (sortField !== null) {
      rows.sort((a, b) => {
        const av = a[sortField as string];
        const bv = b[sortField as string];
        const cmp = typeof av === 'number' && typeof bv === 'number'
          ? av - bv
          : String(av ?? '') < String(bv ?? '') ? -1 : String(av ?? '') > String(bv ?? '') ? 1 : 0;
        return sortDir === 'desc' ? -cmp : cmp;
      });
    }
    return rows;
  });
  const total = $derived(
    hasQueryAction ? (queryTotal ?? initialRows.length) : displayRows.length,
  );
  const pageCount = $derived(Math.max(1, Math.ceil(total / intent.pageSize)));
  const rows = $derived(
    hasQueryAction
      ? // Before the first query completes (SSR / pre-hydration), the initial
        // route rows ARE the current page — render them instead of a flash of
        // the empty state. Once queryTotal is set (even 0), it is authoritative.
        queryTotal === null
          ? initialRows.slice(0, intent.pageSize)
          : displayRows
      : displayRows.slice(page * intent.pageSize, (page + 1) * intent.pageSize),
  );
  const tableState: UiTableState = $derived({
    search,
    filters: filterValues,
    sortField,
    sortDirection: sortDir,
    page,
    pageCount,
    total,
    pending,
  });

  async function runQuery(nextPage: number, nextSortField: string | null, nextSortDir: 'asc' | 'desc'): Promise<void> {
    if (!hasQueryAction) return;
    const token = ++queryToken;
    const payload: QueryPayload = { limit: intent.pageSize, offset: nextPage * intent.pageSize };
    const activeFilters: Record<string, string> = {};
    for (const [field, value] of Object.entries(filterValues)) if (value !== '') activeFilters[field] = value;
    if (Object.keys(activeFilters).length > 0) payload.filters = activeFilters;
    if (search.trim() !== '') payload.search = { text: search.trim(), fields: intent.search.fields };
    // ALWAYS dispatch an explicit sort: the user-selected sort when one is
    // active, otherwise the view's declared initial sort. Omitting `sort`
    // would hand the query to the data adapter's own list order, which can
    // differ from the declared view order the current page was seeded with.
    if (nextSortField !== null) {
      payload.sort = [{ field: nextSortField, direction: nextSortDir }];
    } else if (declaredSort.length > 0) {
      payload.sort = declaredSort;
    }
    pending = true;
    try {
      const result = await dispatch(String(surface.queryActionId), payload);
      if (token !== queryToken) return; // a newer query superseded this one
      if (result.ok && Array.isArray((result.value as { rows?: unknown }).rows)) {
        queryRows = (result.value as { rows: Record<string, unknown>[] }).rows;
        queryTotal = (result.value as { total?: number }).total ?? queryRows.length;
      }
    } finally {
      if (token === queryToken) pending = false;
    }
  }

  async function onSearch(value: string): Promise<void> {
    search = value;
    page = 0;
    await runQuery(0, sortField, sortDir);
  }
  async function onFilter(field: string, value: string): Promise<void> {
    filterValues = { ...filterValues, [field]: value };
    page = 0;
    await runQuery(0, sortField, sortDir);
  }
  async function onSort(field: string): Promise<void> {
    const nextDir: 'asc' | 'desc' = sortField === field && sortDir === 'asc' ? 'desc' : 'asc';
    sortField = field;
    sortDir = nextDir;
    page = 0;
    await runQuery(0, field, nextDir);
  }
  async function onPage(nextPage: number): Promise<void> {
    page = Math.min(Math.max(0, nextPage), pageCount - 1);
    await runQuery(page, sortField, sortDir);
  }

  /** Declared per-row action: dispatch/navigation with row-derived input. */
  async function onRowAction(row: Readonly<Record<string, unknown>>): Promise<void> {
    if (intent.rowAction === undefined) return;
    const actionId = intent.rowAction.actionId;
    const input = deriveRowActionInput(intent.rowAction, row);
    if (run !== undefined) {
      await run(actionId, input);
      return;
    }
    await dispatch(actionId, input);
  }
  /** FT-1: resolve one row's declared navigation binding to its real href. */
  function rowLink(row: Readonly<Record<string, unknown>>): { href: string; label: string } | undefined {
    if (intent.rowDetail === undefined || planRoutes === undefined) return undefined;
    return resolveRowDetailLink(intent.rowDetail, planRoutes, row);
  }
</script>

<RecordsTable {intent} {rows} state={tableState} {registry} {rowLink} {navigate} {onSearch} {onFilter} {onSort} {onPage} {onRowAction} />
